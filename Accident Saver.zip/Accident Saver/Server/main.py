"""
Main Server Application - Car Safety System
"""

from flask import Flask, request, jsonify, render_template_string
from flask_socketio import SocketIO, emit
from datetime import datetime
import threading

from config import SERVER_HOST, SERVER_PORT, DEBUG
from database import Database
from sensor_manager import SensorManager
from alert_system import AlertSystem
from emergency_contacts import EmergencyContactManager
from utils import log_event, generate_confirmation_code

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'car_safety_secret_key_change_in_production'
socketio = SocketIO(app, cors_allowed_origins="*")

# Initialize components
db = Database()
alert_system = AlertSystem(db)
sensor_manager = SensorManager(db, alert_system)
contact_manager = EmergencyContactManager(db)

# ================== API ROUTES ==================

@app.route('/')
def index():
    """Home page with system status"""
    return render_template_string(DASHBOARD_HTML)

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0"
    })

# ================== SENSOR ENDPOINTS ==================

@app.route('/api/sensor_data', methods=['POST'])
def receive_sensor_data():
    """Receive sensor data from ESP32"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data received"}), 400
        
        log_event("sensor", f"Data received from {data.get('device_id')}", 
                  {"is_black": data.get("is_black"), "light_level": data.get("light_level")})
        
        # Process sensor data
        response = sensor_manager.process_sensor_data(data)
        
        # Emit real-time update via WebSocket
        socketio.emit('sensor_update', {
            "device_id": data.get("device_id"),
            "is_black": data.get("is_black"),
            "light_level": data.get("light_level"),
            "timestamp": datetime.now().isoformat()
        })
        
        return jsonify(response)
    
    except Exception as e:
        log_event("error", f"Sensor data processing error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/commands/<device_id>', methods=['GET'])
def get_device_commands(device_id):
    """Get pending commands for a device"""
    commands = db.get_pending_commands(device_id)
    
    command_list = []
    for cmd in commands:
        command_list.append({
            "id": cmd["id"],
            "type": cmd["command_type"],
            "data": cmd["command_data"]
        })
        db.mark_command_executed(cmd["id"])
    
    return jsonify({"commands": command_list})

@app.route('/api/sensors', methods=['GET'])
def get_all_sensors():
    """Get status of all sensors"""
    statuses = sensor_manager.get_all_sensors_status()
    return jsonify({"sensors": statuses})

@app.route('/api/sensors/<device_id>', methods=['GET'])
def get_sensor_status(device_id):
    """Get status of a specific sensor"""
    status = sensor_manager.get_sensor_status(device_id)
    if status:
        return jsonify(status)
    return jsonify({"error": "Sensor not found"}), 404

@app.route('/api/sensors/<device_id>/reset', methods=['POST'])
def reset_sensor(device_id):
    """Reset a sensor"""
    success = sensor_manager.reset_sensor(device_id)
    if success:
        return jsonify({"message": "Sensor reset successfully"})
    return jsonify({"error": "Sensor not found"}), 404

# ================== VEHICLE ENDPOINTS ==================

@app.route('/api/vehicles', methods=['POST'])
def register_vehicle():
    """Register a new vehicle"""
    data = request.get_json()
    
    required = ["vehicle_id", "owner_name", "owner_phone"]
    if not all(k in data for k in required):
        return jsonify({"error": "Missing required fields"}), 400
    
    vehicle_id = db.add_vehicle(
        vehicle_id=data["vehicle_id"],
        owner_name=data["owner_name"],
        owner_phone=data["owner_phone"],
        owner_email=data.get("owner_email", "")
    )
    
    return jsonify({"message": "Vehicle registered", "id": vehicle_id})

@app.route('/api/vehicles/<vehicle_id>', methods=['GET'])
def get_vehicle(vehicle_id):
    """Get vehicle details"""
    vehicle = db.get_vehicle(vehicle_id)
    if vehicle:
        return jsonify(dict(vehicle))
    return jsonify({"error": "Vehicle not found"}), 404

@app.route('/api/vehicles/<vehicle_id>/sensors', methods=['POST'])
def associate_sensor(vehicle_id):
    """Associate a sensor with a vehicle"""
    data = request.get_json()
    device_id = data.get("device_id")
    
    if not device_id:
        return jsonify({"error": "device_id required"}), 400
    
    sensor_manager.associate_sensor_with_vehicle(device_id, vehicle_id)
    return jsonify({"message": "Sensor associated with vehicle"})

# ================== CONTACT ENDPOINTS ==================

@app.route('/api/vehicles/<vehicle_id>/contacts', methods=['GET'])
def get_contacts(vehicle_id):
    """Get emergency contacts for a vehicle"""
    contacts = contact_manager.get_vehicle_contacts(vehicle_id)
    return jsonify({"contacts": contacts})

@app.route('/api/vehicles/<vehicle_id>/contacts', methods=['POST'])
def add_contact(vehicle_id):
    """Add emergency contact for a vehicle"""
    data = request.get_json()
    
    if not data.get("contact_name") or not data.get("contact_phone"):
        return jsonify({"error": "contact_name and contact_phone required"}), 400
    
    contact_id = contact_manager.add_vehicle_contact(
        vehicle_id=vehicle_id,
        contact_name=data["contact_name"],
        contact_phone=data["contact_phone"],
        contact_email=data.get("contact_email"),
        relationship=data.get("relationship"),
        priority=data.get("priority", 1)
    )
    
    return jsonify({"message": "Contact added", "id": contact_id})

# ================== ALERT ENDPOINTS ==================

@app.route('/api/alerts', methods=['GET'])
def get_active_alerts():
    """Get all active alerts"""
    alerts = db.get_active_alerts()
    return jsonify({"alerts": [dict(a) for a in alerts]})

@app.route('/api/alerts/<vehicle_id>', methods=['GET'])
def get_vehicle_alerts(vehicle_id):
    """Get alerts for a specific vehicle"""
    alerts = db.get_active_alerts(vehicle_id)
    return jsonify({"alerts": [dict(a) for a in alerts]})

@app.route('/api/alerts/<int:alert_id>/respond', methods=['POST'])
def respond_to_alert(alert_id):
    """Driver responds to an alert"""
    data = request.get_json()
    response = data.get("response", "")
    vehicle_id = data.get("vehicle_id")
    
    if not vehicle_id:
        return jsonify({"error": "vehicle_id required"}), 400
    
    success, message = alert_system.driver_response(vehicle_id, response)
    
    return jsonify({
        "success": success,
        "message": message
    })

@app.route('/api/alerts/<int:alert_id>/resolve', methods=['POST'])
def resolve_alert(alert_id):
    """Resolve an alert (by responder)"""
    data = request.get_json()
    responder_id = data.get("responder_id", "unknown")
    notes = data.get("notes", "")
    
    success, message = alert_system.resolve_by_responder(alert_id, responder_id, notes)
    
    if success:
        socketio.emit('alert_resolved', {"alert_id": alert_id})
        return jsonify({"message": message})
    
    return jsonify({"error": message}), 400

# ================== DRIVER RESPONSE ENDPOINT ==================

@app.route('/api/driver/response', methods=['POST'])
def driver_quick_response():
    """Quick response endpoint for drivers"""
    data = request.get_json()
    
    vehicle_id = data.get("vehicle_id")
    response = data.get("response")  # "safe" or "help"
    
    if not vehicle_id or not response:
        return jsonify({"error": "vehicle_id and response required"}), 400
    
    success, message = alert_system.driver_response(vehicle_id, response)
    
    return jsonify({
        "success": success,
        "message": message
    })

# ================== WEBSOCKET EVENTS ==================

@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    log_event("websocket", "Client connected")
    emit('connected', {"message": "Connected to Car Safety System"})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    log_event("websocket", "Client disconnected")

@socketio.on('subscribe_vehicle')
def handle_subscribe(data):
    """Subscribe to vehicle updates"""
    vehicle_id = data.get("vehicle_id")
    log_event("websocket", f"Client subscribed to vehicle {vehicle_id}")
    emit('subscribed', {"vehicle_id": vehicle_id})

# ================== DASHBOARD HTML ==================

DASHBOARD_HTML = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Safety System Dashboard</title>
    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        h1 { 
            text-align: center; 
            margin-bottom: 30px;
            font-size: 2.5em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .card {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
        }
        .card h2 { 
            margin-bottom: 15px; 
            color: #00d4ff;
            font-size: 1.3em;
        }
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 2s infinite;
        }
        .status-ok { background: #00ff88; }
        .status-warning { background: #ffaa00; }
        .status-danger { background: #ff4444; animation: pulse-danger 0.5s infinite; }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        @keyframes pulse-danger {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.7; transform: scale(1.2); }
        }
        .sensor-list { list-style: none; }
        .sensor-item {
            background: rgba(0,0,0,0.2);
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .alert-item {
            background: rgba(255,68,68,0.2);
            border-left: 4px solid #ff4444;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 0 8px 8px 0;
        }
        .btn {
            background: linear-gradient(135deg, #00d4ff, #0099cc);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            color: white;
            cursor: pointer;
            font-weight: bold;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,212,255,0.4);
        }
        .btn-danger { background: linear-gradient(135deg, #ff4444, #cc0000); }
        .btn-success { background: linear-gradient(135deg, #00ff88, #00cc6a); }
        .log-container {
            height: 200px;
            overflow-y: auto;
            background: rgba(0,0,0,0.3);
            padding: 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 0.9em;
        }
        .log-entry {
            padding: 5px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .timestamp { color: #888; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .stat-box {
            text-align: center;
            padding: 15px;
            background: rgba(0,0,0,0.2);
            border-radius: 8px;
        }
        .stat-value {
            font-size: 2em;
            font-weight: bold;
            color: #00d4ff;
        }
        .stat-label { font-size: 0.9em; color: #888; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚗 Car Safety System Dashboard</h1>
        
        <div class="dashboard">
            <!-- System Status -->
            <div class="card">
                <h2>📊 System Status</h2>
                <div class="stats-grid">
                    <div class="stat-box">
                        <div class="stat-value" id="sensor-count">0</div>
                        <div class="stat-label">Active Sensors</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value" id="alert-count">0</div>
                        <div class="stat-label">Active Alerts</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value" id="vehicle-count">0</div>
                        <div class="stat-label">Vehicles</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-value" id="connection-status">●</div>
                        <div class="stat-label">Connection</div>
                    </div>
                </div>
            </div>
            
            <!-- Sensors -->
            <div class="card">
                <h2>📡 Sensors</h2>
                <ul class="sensor-list" id="sensor-list">
                    <li class="sensor-item">
                        <span>No sensors connected</span>
                    </li>
                </ul>
            </div>
            
            <!-- Active Alerts -->
            <div class="card">
                <h2>🚨 Active Alerts</h2>
                <div id="alert-list">
                    <p style="color: #888;">No active alerts</p>
                </div>
            </div>
            
            <!-- Event Log -->
            <div class="card">
                <h2>📜 Event Log</h2>
                <div class="log-container" id="log-container">
                    <div class="log-entry">
                        <span class="timestamp">[System]</span> Dashboard initialized
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <h2>⚡ Quick Actions</h2>
                <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                    <button class="btn" onclick="refreshData()">🔄 Refresh</button>
                    <button class="btn btn-success" onclick="testAlert()">🧪 Test Alert</button>
                    <button class="btn btn-danger" onclick="resetAllSensors()">🔄 Reset Sensors</button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        const socket = io();
        
        socket.on('connect', () => {
            document.getElementById('connection-status').style.color = '#00ff88';
            addLog('Connected to server');
        });
        
        socket.on('disconnect', () => {
            document.getElementById('connection-status').style.color = '#ff4444';
            addLog('Disconnected from server');
        });
        
        socket.on('sensor_update', (data) => {
            addLog(`Sensor ${data.device_id}: black=${data.is_black}, level=${data.light_level}`);
            refreshData();
        });
        
        socket.on('alert_resolved', (data) => {
            addLog(`Alert ${data.alert_id} resolved`);
            refreshData();
        });
        
        function addLog(message) {
            const container = document.getElementById('log-container');
            const time = new Date().toLocaleTimeString();
            const entry = document.createElement('div');
            entry.className = 'log-entry';
            entry.innerHTML = `<span class="timestamp">[${time}]</span> ${message}`;
            container.insertBefore(entry, container.firstChild);
        }
        
        function refreshData() {
            // Fetch sensors
            fetch('/api/sensors')
                .then(r => r.json())
                .then(data => {
                    const list = document.getElementById('sensor-list');
                    document.getElementById('sensor-count').textContent = data.sensors.length;
                    
                    if (data.sensors.length === 0) {
                        list.innerHTML = '<li class="sensor-item"><span>No sensors connected</span></li>';
                        return;
                    }
                    
                    list.innerHTML = data.sensors.map(s => `
                        <li class="sensor-item">
                            <div>
                                <span class="status-indicator ${s.is_black ? 'status-danger' : 'status-ok'}"></span>
                                <strong>${s.device_id}</strong>
                                <br><small>Type: ${s.sensor_type} | Level: ${s.light_level}</small>
                            </div>
                            <span>${s.online ? '🟢 Online' : '🔴 Offline'}</span>
                        </li>
                    `).join('');
                });
            
            // Fetch alerts
            fetch('/api/alerts')
                .then(r => r.json())
                .then(data => {
                    const container = document.getElementById('alert-list');
                    document.getElementById('alert-count').textContent = data.alerts.length;
                    
                    if (data.alerts.length === 0) {
                        container.innerHTML = '<p style="color: #888;">No active alerts</p>';
                        return;
                    }
                    
                    container.innerHTML = data.alerts.map(a => `
                        <div class="alert-item">
                            <strong>🚨 Alert #${a.id}</strong>
                            <br>Vehicle: ${a.vehicle_id}
                            <br>Type: ${a.alert_type}
                            <br>Status: ${a.status}
                            <br><small>${a.created_at}</small>
                            <br><button class="btn btn-success" onclick="resolveAlert(${a.id})">Resolve</button>
                        </div>
                    `).join('');
                });
        }
        
        function testAlert() {
            addLog('Test alert triggered');
            alert('Test alert functionality - implement as needed');
        }
        
        function resetAllSensors() {
            addLog('Resetting all sensors...');
            // Implement reset logic
        }
        
        function resolveAlert(alertId) {
            fetch(`/api/alerts/${alertId}/resolve`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({responder_id: 'dashboard', notes: 'Resolved via dashboard'})
            })
            .then(r => r.json())
            .then(data => {
                addLog(`Alert ${alertId} resolved: ${data.message}`);
                refreshData();
            });
        }
        
        // Initial data load
        refreshData();
        
        // Refresh every 5 seconds
        setInterval(refreshData, 5000);
    </script>
</body>
</html>
'''

# ================== MAIN ENTRY POINT ==================

def setup_sample_data():
    """Setup sample data for testing"""
    # Register a sample vehicle
    db.add_vehicle(
        vehicle_id="VH001",
        owner_name="John Doe",
        owner_phone="+919876543210",
        owner_email="john.doe@example.com"
    )
    
    # Add emergency contacts
    contact_manager.add_vehicle_contact(
        vehicle_id="VH001",
        contact_name="Jane Doe",
        contact_phone="+919876543211",
        contact_email="jane.doe@example.com",
        relationship="Spouse",
        priority=1
    )
    
    contact_manager.add_vehicle_contact(
        vehicle_id="VH001",
        contact_name="Emergency Contact",
        contact_phone="+919876543212",
        relationship="Friend",
        priority=2
    )
    
    log_event("setup", "Sample data created")

if __name__ == '__main__':
    log_event("startup", "Car Safety System starting...")
    
    # Setup sample data
    setup_sample_data()
    
    # Run the server
    print(f"""
    ╔══════════════════════════════════════════════════════════╗
    ║           CAR SAFETY SYSTEM - SERVER STARTED             ║
    ╠══════════════════════════════════════════════════════════╣
    ║  Dashboard: http://{SERVER_HOST}:{SERVER_PORT}                      ║
    ║  API Base:  http://{SERVER_HOST}:{SERVER_PORT}/api                  ║
    ║                                                          ║
    ║  Endpoints:                                              ║
    ║  - POST /api/sensor_data     (ESP32 data)               ║
    ║  - GET  /api/sensors         (All sensors)              ║
    ║  - POST /api/vehicles        (Register vehicle)         ║
    ║  - POST /api/driver/response (Driver responds)          ║
    ║  - GET  /api/alerts          (Active alerts)            ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    
    socketio.run(app, host=SERVER_HOST, port=SERVER_PORT, debug=DEBUG)