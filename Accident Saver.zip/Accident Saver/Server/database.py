"""
Database Handler for Car Safety System
"""

import sqlite3
from datetime import datetime
from contextlib import contextmanager

class Database:
    """SQLite Database Manager"""
    
    def __init__(self, db_path="car_safety.db"):
        self.db_path = db_path
        self.init_database()
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def init_database(self):
        """Initialize database tables"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Vehicles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vehicles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    vehicle_id TEXT UNIQUE NOT NULL,
                    owner_name TEXT,
                    owner_phone TEXT,
                    owner_email TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Emergency contacts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS emergency_contacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    vehicle_id TEXT NOT NULL,
                    contact_name TEXT NOT NULL,
                    contact_phone TEXT NOT NULL,
                    contact_email TEXT,
                    relationship TEXT,
                    priority INTEGER DEFAULT 1,
                    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id)
                )
            ''')
            
            # Sensors table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sensors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id TEXT UNIQUE NOT NULL,
                    sensor_type TEXT NOT NULL,
                    vehicle_id TEXT,
                    location_description TEXT,
                    is_active BOOLEAN DEFAULT TRUE,
                    last_seen TIMESTAMP,
                    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id)
                )
            ''')
            
            # Sensor readings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sensor_readings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id TEXT NOT NULL,
                    is_black BOOLEAN,
                    light_level INTEGER,
                    left_side_black BOOLEAN,
                    right_side_black BOOLEAN,
                    latitude REAL,
                    longitude REAL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (device_id) REFERENCES sensors(device_id)
                )
            ''')
            
            # Alerts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    vehicle_id TEXT NOT NULL,
                    alert_type TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    driver_responded BOOLEAN DEFAULT FALSE,
                    response_message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    resolved_at TIMESTAMP,
                    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id)
                )
            ''')
            
            # Notifications table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    alert_id INTEGER,
                    recipient_type TEXT NOT NULL,
                    recipient_contact TEXT NOT NULL,
                    notification_type TEXT NOT NULL,
                    message TEXT,
                    status TEXT DEFAULT 'pending',
                    sent_at TIMESTAMP,
                    FOREIGN KEY (alert_id) REFERENCES alerts(id)
                )
            ''')
            
            # Commands queue table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS command_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id TEXT NOT NULL,
                    command_type TEXT NOT NULL,
                    command_data TEXT,
                    status TEXT DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    executed_at TIMESTAMP
                )
            ''')
    
    # Vehicle operations
    def add_vehicle(self, vehicle_id, owner_name, owner_phone, owner_email):
        """Add a new vehicle"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO vehicles (vehicle_id, owner_name, owner_phone, owner_email)
                VALUES (?, ?, ?, ?)
            ''', (vehicle_id, owner_name, owner_phone, owner_email))
            return cursor.lastrowid
    
    def get_vehicle(self, vehicle_id):
        """Get vehicle by ID"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM vehicles WHERE vehicle_id = ?', (vehicle_id,))
            return cursor.fetchone()
    
    # Emergency contact operations
    def add_emergency_contact(self, vehicle_id, contact_name, contact_phone, 
                              contact_email=None, relationship=None, priority=1):
        """Add emergency contact for a vehicle"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO emergency_contacts 
                (vehicle_id, contact_name, contact_phone, contact_email, relationship, priority)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (vehicle_id, contact_name, contact_phone, contact_email, relationship, priority))
            return cursor.lastrowid
    
    def get_emergency_contacts(self, vehicle_id):
        """Get all emergency contacts for a vehicle"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM emergency_contacts 
                WHERE vehicle_id = ? 
                ORDER BY priority ASC
            ''', (vehicle_id,))
            return cursor.fetchall()
    
    # Sensor operations
    def register_sensor(self, device_id, sensor_type, vehicle_id=None, location_description=None):
        """Register a new sensor"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO sensors 
                (device_id, sensor_type, vehicle_id, location_description, is_active, last_seen)
                VALUES (?, ?, ?, ?, TRUE, ?)
            ''', (device_id, sensor_type, vehicle_id, location_description, datetime.now()))
            return cursor.lastrowid
    
    def update_sensor_status(self, device_id):
        """Update sensor last seen timestamp"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE sensors SET last_seen = ? WHERE device_id = ?
            ''', (datetime.now(), device_id))
    
    def get_sensor(self, device_id):
        """Get sensor by device ID"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM sensors WHERE device_id = ?', (device_id,))
            return cursor.fetchone()
    
    # Sensor readings operations
    def add_sensor_reading(self, device_id, is_black, light_level, 
                           left_side_black, right_side_black, latitude, longitude):
        """Add a sensor reading"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO sensor_readings 
                (device_id, is_black, light_level, left_side_black, right_side_black, latitude, longitude)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (device_id, is_black, light_level, left_side_black, right_side_black, latitude, longitude))
            return cursor.lastrowid
    
    def get_recent_readings(self, device_id, limit=10):
        """Get recent sensor readings"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM sensor_readings 
                WHERE device_id = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (device_id, limit))
            return cursor.fetchall()
    
    # Alert operations
    def create_alert(self, vehicle_id, alert_type):
        """Create a new alert"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO alerts (vehicle_id, alert_type, status)
                VALUES (?, ?, 'pending')
            ''', (vehicle_id, alert_type))
            return cursor.lastrowid
    
    def update_alert_status(self, alert_id, status, driver_responded=False, response_message=None):
        """Update alert status"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            resolved_at = datetime.now() if status == 'resolved' else None
            cursor.execute('''
                UPDATE alerts 
                SET status = ?, driver_responded = ?, response_message = ?, resolved_at = ?
                WHERE id = ?
            ''', (status, driver_responded, response_message, resolved_at, alert_id))
    
    def get_active_alerts(self, vehicle_id=None):
        """Get active alerts"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if vehicle_id:
                cursor.execute('''
                    SELECT * FROM alerts 
                    WHERE vehicle_id = ? AND status IN ('pending', 'escalated')
                    ORDER BY created_at DESC
                ''', (vehicle_id,))
            else:
                cursor.execute('''
                    SELECT * FROM alerts 
                    WHERE status IN ('pending', 'escalated')
                    ORDER BY created_at DESC
                ''')
            return cursor.fetchall()
    
    def get_alert(self, alert_id):
        """Get alert by ID"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM alerts WHERE id = ?', (alert_id,))
            return cursor.fetchone()
    
    # Notification operations
    def add_notification(self, alert_id, recipient_type, recipient_contact, 
                        notification_type, message):
        """Add a notification record"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO notifications 
                (alert_id, recipient_type, recipient_contact, notification_type, message)
                VALUES (?, ?, ?, ?, ?)
            ''', (alert_id, recipient_type, recipient_contact, notification_type, message))
            return cursor.lastrowid
    
    def update_notification_status(self, notification_id, status):
        """Update notification status"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            sent_at = datetime.now() if status == 'sent' else None
            cursor.execute('''
                UPDATE notifications SET status = ?, sent_at = ? WHERE id = ?
            ''', (status, sent_at, notification_id))
    
    # Command queue operations
    def add_command(self, device_id, command_type, command_data=None):
        """Add command to queue"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO command_queue (device_id, command_type, command_data)
                VALUES (?, ?, ?)
            ''', (device_id, command_type, command_data))
            return cursor.lastrowid
    
    def get_pending_commands(self, device_id):
        """Get pending commands for a device"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM command_queue 
                WHERE device_id = ? AND status = 'pending'
                ORDER BY created_at ASC
            ''', (device_id,))
            return cursor.fetchall()
    
    def mark_command_executed(self, command_id):
        """Mark command as executed"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE command_queue 
                SET status = 'executed', executed_at = ?
                WHERE id = ?
            ''', (datetime.now(), command_id))