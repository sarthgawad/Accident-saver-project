"""
ESP32 Main Program - Sensor Reading and Data Transmission
"""

import machine
import time
import urequests
import ujson
import gc
from config import (
    SERVER_URL, DEVICE_ID, SENSOR_TYPE,
    LIGHT_SENSOR_PIN, LED_STATUS_PIN,
    BLACK_THRESHOLD, SENSOR_READ_INTERVAL, SEND_INTERVAL,
    CAMERA_ENABLED
)

class SensorModule:
    """Handles all sensor operations"""
    
    def __init__(self):
        # Initialize ADC for light sensor (LDR)
        self.light_sensor = machine.ADC(machine.Pin(LIGHT_SENSOR_PIN))
        self.light_sensor.atten(machine.ADC.ATTN_11DB)  # Full range: 0-4095
        self.light_sensor.width(machine.ADC.WIDTH_12BIT)
        
        # Status LED
        self.led = machine.Pin(LED_STATUS_PIN, machine.Pin.OUT)
        
        # State tracking
        self.is_black = False
        self.last_reading = 0
        self.consecutive_black_count = 0
        self.black_confirmation_threshold = 5  # Number of consecutive readings
        
        # Camera setup (if enabled)
        self.camera = None
        if CAMERA_ENABLED:
            self._init_camera()
    
    def _init_camera(self):
        """Initialize camera module (OV2640)"""
        try:
            import camera
            camera.init(0, format=camera.JPEG)
            self.camera = camera
            print("Camera initialized successfully")
        except Exception as e:
            print(f"Camera initialization failed: {e}")
            self.camera = None
    
    def read_light_level(self):
        """Read light level from LDR sensor"""
        readings = []
        for _ in range(5):
            readings.append(self.light_sensor.read())
            time.sleep_ms(10)
        
        # Average of readings for stability
        self.last_reading = sum(readings) // len(readings)
        return self.last_reading
    
    def check_black_condition(self):
        """
        Check if the sensor detects 'black' (obstruction/darkness)
        Returns True if black condition is confirmed
        """
        reading = self.read_light_level()
        
        if reading < BLACK_THRESHOLD:
            self.consecutive_black_count += 1
        else:
            self.consecutive_black_count = 0
        
        # Confirm black only after consecutive readings
        if self.consecutive_black_count >= self.black_confirmation_threshold:
            self.is_black = True
        else:
            self.is_black = False
        
        return self.is_black
    
    def capture_image(self):
        """Capture image from camera (if available)"""
        if self.camera:
            try:
                import camera
                buf = camera.capture()
                return buf
            except Exception as e:
                print(f"Image capture failed: {e}")
        return None
    
    def analyze_camera_black(self, image_data):
        """
        Analyze camera image for black/obstruction
        Returns True if image is predominantly black
        """
        if not image_data:
            return False
        
        # Simple analysis: check if image is mostly dark
        # In practice, you'd use more sophisticated image processing
        dark_pixels = 0
        total_pixels = len(image_data)
        
        for byte in image_data[:1000]:  # Sample first 1000 bytes
            if byte < 30:  # Dark threshold
                dark_pixels += 1
        
        return (dark_pixels / min(1000, total_pixels)) > 0.8
    
    def blink_led(self, times=1, delay=100):
        """Blink status LED"""
        for _ in range(times):
            self.led.on()
            time.sleep_ms(delay)
            self.led.off()
            time.sleep_ms(delay)


class DataTransmitter:
    """Handles communication with the main server"""
    
    def __init__(self, server_url, device_id):
        self.server_url = server_url
        self.device_id = device_id
        self.endpoint = f"{server_url}/api/sensor_data"
    
    def send_data(self, data):
        """Send sensor data to server"""
        try:
            payload = ujson.dumps(data)
            headers = {"Content-Type": "application/json"}
            
            response = urequests.post(
                self.endpoint,
                data=payload,
                headers=headers
            )
            
            result = response.json()
            response.close()
            gc.collect()  # Free memory
            
            return result
        
        except Exception as e:
            print(f"Data transmission error: {e}")
            return None
    
    def check_server_commands(self):
        """Check for any commands from server"""
        try:
            response = urequests.get(
                f"{self.server_url}/api/commands/{self.device_id}"
            )
            commands = response.json()
            response.close()
            gc.collect()
            return commands
        except Exception as e:
            print(f"Command check error: {e}")
            return None


class MainController:
    """Main controller for the ESP32 sensor system"""
    
    def __init__(self):
        self.sensor = SensorModule()
        self.transmitter = DataTransmitter(SERVER_URL, DEVICE_ID)
        self.last_send_time = 0
        self.left_black = False
        self.right_black = False
    
    def prepare_sensor_data(self):
        """Prepare sensor data packet for transmission"""
        is_black = self.sensor.check_black_condition()
        
        data = {
            "device_id": DEVICE_ID,
            "sensor_type": SENSOR_TYPE,
            "timestamp": time.time(),
            "is_black": is_black,
            "light_level": self.sensor.last_reading,
            "threshold": BLACK_THRESHOLD,
            "left_side_black": self.left_black,
            "right_side_black": self.right_black,
            "gps_location": self.get_gps_location(),
            "battery_level": self.get_battery_level()
        }
        
        return data
    
    def get_gps_location(self):
        """Get GPS location (placeholder - implement with GPS module)"""
        # TODO: Implement actual GPS reading if GPS module is connected
        return {
            "latitude": 0.0,
            "longitude": 0.0,
            "accuracy": 0
        }
    
    def get_battery_level(self):
        """Get battery level (placeholder)"""
        # TODO: Implement actual battery reading
        return 100
    
    def run(self):
        """Main loop"""
        print(f"Starting sensor module: {DEVICE_ID} ({SENSOR_TYPE})")
        self.sensor.blink_led(3, 200)  # Startup indication
        
        while True:
            try:
                # Read sensor
                is_black = self.sensor.check_black_condition()
                
                # Visual indication
                if is_black:
                    self.sensor.led.on()
                else:
                    self.sensor.led.off()
                
                # Send data at intervals
                current_time = time.ticks_ms()
                if time.ticks_diff(current_time, self.last_send_time) >= SEND_INTERVAL:
                    data = self.prepare_sensor_data()
                    result = self.transmitter.send_data(data)
                    
                    if result:
                        print(f"Data sent: black={is_black}, level={self.sensor.last_reading}")
                        
                        # Handle server commands
                        if result.get("command"):
                            self.handle_command(result["command"])
                    
                    self.last_send_time = current_time
                
                # Check for server commands periodically
                if time.ticks_diff(current_time, self.last_send_time) % 5000 < SENSOR_READ_INTERVAL:
                    commands = self.transmitter.check_server_commands()
                    if commands:
                        for cmd in commands.get("commands", []):
                            self.handle_command(cmd)
                
                time.sleep_ms(SENSOR_READ_INTERVAL)
                
            except Exception as e:
                print(f"Main loop error: {e}")
                self.sensor.blink_led(5, 50)  # Error indication
                time.sleep(1)
    
    def handle_command(self, command):
        """Handle commands from server"""
        cmd_type = command.get("type")
        
        if cmd_type == "reset":
            print("Resetting sensor state")
            self.sensor.consecutive_black_count = 0
            self.sensor.is_black = False
            
        elif cmd_type == "calibrate":
            print("Calibrating sensor")
            # Take current reading as baseline
            reading = self.sensor.read_light_level()
            print(f"New baseline: {reading}")
            
        elif cmd_type == "reboot":
            print("Rebooting...")
            machine.reset()


# Run the main controller
if __name__ == "__main__":
    controller = MainController()
    controller.run()