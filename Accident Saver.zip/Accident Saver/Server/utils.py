"""
Utility Functions
"""

import hashlib
import random
import string
from datetime import datetime

def generate_confirmation_code(length=6):
    """Generate a random confirmation code"""
    return ''.join(random.choices(string.digits, k=length))

def generate_device_id():
    """Generate a unique device ID"""
    timestamp = datetime.now().isoformat()
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"ESP32_{random_part}"

def hash_phone_number(phone):
    """Hash phone number for privacy"""
    return hashlib.sha256(phone.encode()).hexdigest()[:16]

def format_phone_number(phone):
    """Format phone number for display"""
    # Remove all non-digit characters
    digits = ''.join(filter(str.isdigit, phone))
    
    if len(digits) == 10:
        return f"+91 {digits[:5]} {digits[5:]}"
    elif len(digits) == 12 and digits.startswith("91"):
        return f"+{digits[:2]} {digits[2:7]} {digits[7:]}"
    
    return phone

def validate_phone_number(phone):
    """Validate phone number format"""
    digits = ''.join(filter(str.isdigit, phone))
    return len(digits) >= 10

def validate_email(email):
    """Basic email validation"""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def calculate_severity(sensor_data):
    """
    Calculate severity level based on sensor data
    Returns: "low", "medium", "high", "critical"
    """
    severity = "low"
    
    if sensor_data.get("is_black"):
        severity = "medium"
    
    if sensor_data.get("left_side_black") and sensor_data.get("right_side_black"):
        severity = "high"
    
    # Add more conditions based on additional sensor data
    
    return severity

def format_timestamp(dt):
    """Format datetime for display"""
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def log_event(event_type, message, data=None):
    """Log system events"""
    timestamp = datetime.now().isoformat()
    log_entry = f"[{timestamp}] [{event_type.upper()}] {message}"
    
    if data:
        log_entry += f" | Data: {data}"
    
    print(log_entry)
    
    # In production, write to log file or logging service
    return log_entry