"""
Sensor Manager - Handles ESP32 sensor communication and data processing
"""

from datetime import datetime, timedelta
from collections import defaultdict

class SensorState:
    """Tracks state for a single sensor"""
    
    def __init__(self, device_id, sensor_type):
        self.device_id = device_id
        self.sensor_type = sensor_type
        self.is_black = False
        self.light_level = 0
        self.left_side_black = False
        self.right_side_black = False
        self.last_update = None
        self.consecutive_black_count = 0
        self.black_start_time = None
        self.location = {"latitude": 0, "longitude": 0}


class SensorManager:
    """Manages all sensor inputs and coordinates alert triggering"""
    
    def __init__(self, database, alert_system):
        self.db = database
        self.alert_system = alert_system
        self.sensors = {}  # device_id -> SensorState
        self.vehicle_sensors = defaultdict(list)  # vehicle_id -> [device_ids]
        
        # Detection parameters
        self.black_confirmation_time = 3  # seconds of continuous black before alert
        self.dual_side_confirmation_time = 2  # seconds for dual-side confirmation
    
    def process_sensor_data(self, data):
        """
        Process incoming sensor data from ESP32
        Returns response data for the ESP32
        """
        device_id = data.get("device_id")
        sensor_type = data.get("sensor_type")
        
        # Get or create sensor state
        if device_id not in self.sensors:
            self.sensors[device_id] = SensorState(device_id, sensor_type)
            self.db.register_sensor(device_id, sensor_type)
        
        sensor = self.sensors[device_id]
        
        # Update sensor state
        sensor.is_black = data.get("is_black", False)
        sensor.light_level = data.get("light_level", 0)
        sensor.left_side_black = data.get("left_side_black", False)
        sensor.right_side_black = data.get("right_side_black", False)
        sensor.last_update = datetime.now()
        
        # Update location if available
        gps = data.get("gps_location", {})
        if gps.get("latitude") and gps.get("longitude"):
            sensor.location = gps
        
        # Store reading in database
        self.db.add_sensor_reading(
            device_id=device_id,
            is_black=sensor.is_black,
            light_level=sensor.light_level,
            left_side_black=sensor.left_side_black,
            right_side_black=sensor.right_side_black,
            latitude=sensor.location.get("latitude", 0),
            longitude=sensor.location.get("longitude", 0)
        )
        
        # Update sensor status in database
        self.db.update_sensor_status(device_id)
        
        # Analyze for alert conditions
        alert_triggered = self._analyze_sensor_state(sensor, data)
        
        # Prepare response
        response = {
            "status": "ok",
            "received": True,
            "timestamp": datetime.now().isoformat(),
            "alert_triggered": alert_triggered
        }
        
        # Check for pending commands
        commands = self._get_pending_commands(device_id)
        if commands:
            response["command"] = commands[0]
        
        return response
    
    def _analyze_sensor_state(self, sensor, data):
        """
        Analyze sensor state and trigger alerts if necessary
        """
        device_id = sensor.device_id
        vehicle_id = self._get_vehicle_for_sensor(device_id)
        
        if not vehicle_id:
            # Sensor not associated with a vehicle, skip alert logic
            return False
        
        alert_triggered = False
        
        # Check for black condition
        if sensor.is_black:
            if sensor.black_start_time is None:
                sensor.black_start_time = datetime.now()
                sensor.consecutive_black_count = 1
            else:
                sensor.consecutive_black_count += 1
            
            # Check if black condition persisted long enough
            black_duration = (datetime.now() - sensor.black_start_time).total_seconds()
            
            if black_duration >= self.black_confirmation_time:
                # Check for dual-side black (more severe)
                if sensor.left_side_black and sensor.right_side_black:
                    # Both sides black - more serious situation
                    alert_triggered = self._trigger_vehicle_alert(
                        vehicle_id,
                        "dual_side_black",
                        data
                    )
                else:
                    # Single side black
                    alert_triggered = self._trigger_vehicle_alert(
                        vehicle_id,
                        "black_detected",
                        data
                    )
        else:
            # Reset black tracking
            sensor.black_start_time = None
            sensor.consecutive_black_count = 0
        
        return alert_triggered
    
    def _trigger_vehicle_alert(self, vehicle_id, alert_type, sensor_data):
        """Trigger an alert for a vehicle"""
        # Check if there's already an active alert
        existing_alert = self.alert_system.get_active_alert_status(vehicle_id)
        
        if existing_alert:
            print(f"[SENSOR] Alert already active for vehicle {vehicle_id}")
            return False
        
        # Trigger new alert
        self.alert_system.trigger_alert(vehicle_id, alert_type, sensor_data)
        return True
    
    def _get_vehicle_for_sensor(self, device_id):
        """Get the vehicle ID associated with a sensor"""
        sensor = self.db.get_sensor(device_id)
        if sensor:
            return sensor["vehicle_id"]
        return None
    
    def _get_pending_commands(self, device_id):
        """Get pending commands for a sensor"""
        commands = self.db.get_pending_commands(device_id)
        result = []
        for cmd in commands:
            result.append({
                "id": cmd["id"],
                "type": cmd["command_type"],
                "data": cmd["command_data"]
            })
            # Mark as executed
            self.db.mark_command_executed(cmd["id"])
        return result
    
    def associate_sensor_with_vehicle(self, device_id, vehicle_id):
        """Associate a sensor with a vehicle"""
        self.db.register_sensor(
            device_id=device_id,
            sensor_type=self.sensors.get(device_id, SensorState(device_id, "unknown")).sensor_type,
            vehicle_id=vehicle_id
        )
        
        if device_id not in self.vehicle_sensors[vehicle_id]:
            self.vehicle_sensors[vehicle_id].append(device_id)
    
    def get_sensor_status(self, device_id):
        """Get current status of a sensor"""
        if device_id in self.sensors:
            sensor = self.sensors[device_id]
            return {
                "device_id": device_id,
                "sensor_type": sensor.sensor_type,
                "is_black": sensor.is_black,
                "light_level": sensor.light_level,
                "left_side_black": sensor.left_side_black,
                "right_side_black": sensor.right_side_black,
                "last_update": sensor.last_update.isoformat() if sensor.last_update else None,
                "location": sensor.location,
                "online": self._is_sensor_online(sensor)
            }
        return None
    
    def _is_sensor_online(self, sensor, timeout_seconds=30):
        """Check if sensor is online (received data recently)"""
        if sensor.last_update is None:
            return False
        return (datetime.now() - sensor.last_update).total_seconds() < timeout_seconds
    
    def get_all_sensors_status(self):
        """Get status of all sensors"""
        statuses = []
        for device_id in self.sensors:
            status = self.get_sensor_status(device_id)
            if status:
                statuses.append(status)
        return statuses
    
    def send_command_to_sensor(self, device_id, command_type, command_data=None):
        """Send a command to a sensor"""
        self.db.add_command(device_id, command_type, command_data)
        return True
    
    def reset_sensor(self, device_id):
        """Reset sensor state"""
        if device_id in self.sensors:
            sensor = self.sensors[device_id]
            sensor.is_black = False
            sensor.consecutive_black_count = 0
            sensor.black_start_time = None
            self.send_command_to_sensor(device_id, "reset")
            return True
        return False