"""
Emergency Contacts Manager
"""

from geopy.distance import geodesic
from geopy.geocoders import Nominatim

class EmergencyContactManager:
    """Manages emergency contacts and location-based services"""
    
    def __init__(self, database):
        self.db = database
        self.geolocator = Nominatim(user_agent="car_safety_system")
        
        # Nearby alert radius in kilometers
        self.nearby_radius_km = 5
        
        # Registered nearby responders (in production, this would be a larger database)
        self.registered_responders = []
    
    def add_vehicle_contact(self, vehicle_id, contact_name, contact_phone,
                           contact_email=None, relationship=None, priority=1):
        """Add emergency contact for a vehicle"""
        return self.db.add_emergency_contact(
            vehicle_id=vehicle_id,
            contact_name=contact_name,
            contact_phone=contact_phone,
            contact_email=contact_email,
            relationship=relationship,
            priority=priority
        )
    
    def get_vehicle_contacts(self, vehicle_id):
        """Get all emergency contacts for a vehicle"""
        contacts = self.db.get_emergency_contacts(vehicle_id)
        return [dict(c) for c in contacts]
    
    def remove_contact(self, contact_id):
        """Remove an emergency contact"""
        # Implementation would delete from database
        pass
    
    def get_nearby_responders(self, location, radius_km=None):
        """
        Get registered responders near a location
        In production, this would query a database of registered volunteers,
        emergency services, or connected vehicles
        """
        if radius_km is None:
            radius_km = self.nearby_radius_km
        
        nearby = []
        
        for responder in self.registered_responders:
            responder_location = (responder["latitude"], responder["longitude"])
            incident_location = (location["latitude"], location["longitude"])
            
            distance = geodesic(incident_location, responder_location).kilometers
            
            if distance <= radius_km:
                nearby.append({
                    **responder,
                    "distance_km": round(distance, 2)
                })
        
        # Sort by distance
        nearby.sort(key=lambda x: x["distance_km"])
        
        return nearby
    
    def register_responder(self, responder_id, name, phone, latitude, longitude,
                          responder_type="volunteer"):
        """Register a nearby responder/volunteer"""
        self.registered_responders.append({
            "id": responder_id,
            "name": name,
            "phone": phone,
            "latitude": latitude,
            "longitude": longitude,
            "type": responder_type,
            "available": True
        })
    
    def get_address_from_coordinates(self, latitude, longitude):
        """Convert GPS coordinates to address"""
        try:
            location = self.geolocator.reverse(f"{latitude}, {longitude}")
            return location.address if location else "Unknown location"
        except Exception as e:
            print(f"Geocoding error: {e}")
            return f"Lat: {latitude}, Lon: {longitude}"
    
    def get_nearest_hospital(self, latitude, longitude):
        """
        Get nearest hospital to location
        In production, integrate with Google Maps API or similar
        """
        # Placeholder - would use maps API
        return {
            "name": "Nearest Hospital",
            "phone": "102",
            "address": "Hospital Address",
            "distance_km": 0
        }
    
    def get_nearest_police_station(self, latitude, longitude):
        """
        Get nearest police station
        In production, integrate with local services API
        """
        # Placeholder
        return {
            "name": "Police Station",
            "phone": "100",
            "address": "Police Station Address",
            "distance_km": 0
        }  