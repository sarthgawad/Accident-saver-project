"""
Alert System - Handles all alert logic and notifications
"""

import threading
import time
from datetime import datetime
from enum import Enum
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

try:
    from twilio.rest import Client as TwilioClient
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False
    print("Twilio not installed. SMS notifications will be simulated.")

try:
    import pyttsx3
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False
    print("pyttsx3 not installed. Voice alerts will be simulated.")

from config import (
    TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER,
    SMTP_SERVER, SMTP_PORT, EMAIL_ADDRESS, EMAIL_PASSWORD,
    ALERT_TIMEOUT, REPEAT_ALERT_INTERVAL, MAX_ALERT_ATTEMPTS,
    EMERGENCY_CONTACTS, ALERT_MESSAGES
)


class AlertStatus(Enum):
    PENDING = "pending"
    WAITING_RESPONSE = "waiting_response"
    DRIVER_RESPONDED = "driver_responded"
    ESCALATED = "escalated"
    RESOLVED = "resolved"


class AlertType(Enum):
    DRIVER_CHECK = "driver_check"
    ACCIDENT_DETECTED = "accident_detected"
    DUAL_SIDE_BLACK = "dual_side_black"


class AlertSystem:
    """Main alert system controller"""
    
    def __init__(self, database):
        self.db = database
        self.active_alerts = {}  # vehicle_id -> alert_info
        self.alert_timers = {}   # alert_id -> timer
        self.response_callbacks = {}  # alert_id -> callback
        
        # Initialize notification services
        self.twilio_client = None
        if TWILIO_AVAILABLE and TWILIO_ACCOUNT_SID:
            try:
                self.twilio_client = TwilioClient(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
            except Exception as e:
                print(f"Twilio initialization failed: {e}")
        
        # Initialize TTS engine
        self.tts_engine = None
        if TTS_AVAILABLE:
            try:
                self.tts_engine = pyttsx3.init()
            except Exception as e:
                print(f"TTS initialization failed: {e}")
    
    def trigger_alert(self, vehicle_id, alert_type, sensor_data):
        """
        Trigger a new alert based on sensor data
        """
        print(f"[ALERT] Triggering {alert_type} for vehicle {vehicle_id}")
        
        # Create alert in database
        alert_id = self.db.create_alert(vehicle_id, alert_type)
        
        # Store alert info
        alert_info = {
            "id": alert_id,
            "vehicle_id": vehicle_id,
            "type": alert_type,
            "sensor_data": sensor_data,
            "status": AlertStatus.PENDING,
            "attempt_count": 0,
            "created_at": datetime.now()
        }
        
        self.active_alerts[vehicle_id] = alert_info
        
        # Send initial alert to driver
        self._send_driver_alert(alert_info)
        
        return alert_id
    
    def _send_driver_alert(self, alert_info):
        """Send alert to driver and wait for response"""
        vehicle_id = alert_info["vehicle_id"]
        alert_id = alert_info["id"]
        
        alert_info["attempt_count"] += 1
        alert_info["status"] = AlertStatus.WAITING_RESPONSE
        
        message = ALERT_MESSAGES["driver_check"].format(timeout=ALERT_TIMEOUT)
        
        # Send via multiple channels
        vehicle = self.db.get_vehicle(vehicle_id)
        if vehicle:
            # Voice alert (in-car speaker)
            self._play_voice_alert(message)
            
            # SMS to driver
            if vehicle["owner_phone"]:
                self._send_sms(vehicle["owner_phone"], message)
            
            # Push notification (if app is implemented)
            self._send_push_notification(vehicle_id, message)
        
        # Start response timer
        timer = threading.Timer(ALERT_TIMEOUT, self._handle_no_response, args=[alert_info])
        timer.start()
        self.alert_timers[alert_id] = timer
        
        print(f"[ALERT] Driver alert sent. Waiting {ALERT_TIMEOUT}s for response...")
    
    def _handle_no_response(self, alert_info):
        """Handle case when driver doesn't respond"""
        vehicle_id = alert_info["vehicle_id"]
        alert_id = alert_info["id"]
        
        print(f"[ALERT] No response from driver for vehicle {vehicle_id}")
        
        # Check if already resolved
        if alert_info["status"] == AlertStatus.RESOLVED:
            return
        
        # Check attempt count
        if alert_info["attempt_count"] < MAX_ALERT_ATTEMPTS:
            # Retry alert
            print(f"[ALERT] Retrying alert (attempt {alert_info['attempt_count'] + 1}/{MAX_ALERT_ATTEMPTS})")
            time.sleep(REPEAT_ALERT_INTERVAL)
            self._send_driver_alert(alert_info)
        else:
            # Escalate to emergency services
            print(f"[ALERT] Maximum attempts reached. Escalating to emergency services...")
            self._escalate_alert(alert_info)
    
    def _escalate_alert(self, alert_info):
        """Escalate alert to emergency contacts and services"""
        vehicle_id = alert_info["vehicle_id"]
        alert_id = alert_info["id"]
        sensor_data = alert_info["sensor_data"]
        
        alert_info["status"] = AlertStatus.ESCALATED
        self.db.update_alert_status(alert_id, "escalated")
        
        # Get location
        location = self._format_location(sensor_data.get("gps_location", {}))
        
        # Prepare emergency message
        emergency_message = ALERT_MESSAGES["accident_alert"].format(
            location=location,
            vehicle_id=vehicle_id
        )
        
        # 1. Notify nearby people (if location service available)
        self._notify_nearby_people(location, emergency_message)
        
        # 2. Notify hospitals
        self._notify_emergency_service("ambulance", emergency_message, location)
        
        # 3. Notify police
        self._notify_emergency_service("police", emergency_message, location)
        
        # 4. Notify relatives/emergency contacts
        self._notify_relatives(alert_info, location)
        
        # 5. Start continuous alert loop
        self._start_continuous_alerts(alert_info)
    
    def _notify_nearby_people(self, location, message):
        """Notify nearby people/vehicles about the accident"""
        print(f"[ALERT] Notifying nearby people at {location}")
        
        # In a real implementation, this would:
        # 1. Query a location service for nearby registered users
        # 2. Send push notifications to their devices
        # 3. Potentially trigger alerts on nearby vehicles' systems
        
        # For now, log the action
        self.db.add_notification(
            alert_id=None,
            recipient_type="nearby_people",
            recipient_contact=location,
            notification_type="broadcast",
            message=message
        )
    
    def _notify_emergency_service(self, service_type, message, location):
        """Notify emergency service (police, ambulance, etc.)"""
        contact = EMERGENCY_CONTACTS.get(service_type)
        
        print(f"[ALERT] Notifying {service_type}: {contact}")
        
        if contact:
            # In production, integrate with local emergency services API
            # For now, simulate the call/notification
            self._send_sms(contact, f"{message}\nLocation: {location}")
    
    def _notify_relatives(self, alert_info, location):
        """Notify all emergency contacts/relatives"""
        vehicle_id = alert_info["vehicle_id"]
        alert_id = alert_info["id"]
        
        contacts = self.db.get_emergency_contacts(vehicle_id)
        
        message = ALERT_MESSAGES["relative_notification"].format(location=location)
        
        for contact in contacts:
            print(f"[ALERT] Notifying relative: {contact['contact_name']} ({contact['contact_phone']})")
            
            # Send SMS
            if contact["contact_phone"]:
                self._send_sms(contact["contact_phone"], message)
            
            # Send email
            if contact["contact_email"]:
                self._send_email(
                    contact["contact_email"],
                    "EMERGENCY: Vehicle Accident Alert",
                    message
                )
            
            # Record notification
            self.db.add_notification(
                alert_id=alert_id,
                recipient_type="relative",
                recipient_contact=contact["contact_phone"],
                notification_type="sms",
                message=message
            )
    
    def _start_continuous_alerts(self, alert_info):
        """Start continuous alerts until resolved"""
        def continuous_alert_loop():
            while alert_info["status"] == AlertStatus.ESCALATED:
                print(f"[ALERT] Sending continuous emergency alert...")
                
                vehicle_id = alert_info["vehicle_id"]
                location = self._format_location(
                    alert_info["sensor_data"].get("gps_location", {})
                )
                
                message = f"ONGOING EMERGENCY at {location}. Vehicle: {vehicle_id}. Please respond."
                
                # Re-notify all parties
                for contact in self.db.get_emergency_contacts(vehicle_id):
                    if contact["contact_phone"]:
                        self._send_sms(contact["contact_phone"], message)
                
                time.sleep(60)  # Wait 1 minute between continuous alerts
        
        # Start in background thread
        thread = threading.Thread(target=continuous_alert_loop, daemon=True)
        thread.start()
    
    def driver_response(self, vehicle_id, response, confirmation_code=None):
        """
        Handle driver's response to alert
        Returns True if response is valid and alert is resolved
        """
        if vehicle_id not in self.active_alerts:
            return False, "No active alert for this vehicle"
        
        alert_info = self.active_alerts[vehicle_id]
        alert_id = alert_info["id"]
        
        # Validate response (could add confirmation code verification)
        if response.lower() in ["yes", "safe", "ok", "i'm safe", "im safe", "1"]:
            # Driver confirmed safe
            self._resolve_alert(alert_info, "Driver confirmed safe")
            return True, "Alert resolved. Stay safe!"
        
        elif response.lower() in ["help", "emergency", "accident", "0"]:
            # Driver needs help - immediately escalate
            self._escalate_alert(alert_info)
            return True, "Emergency services have been notified. Help is on the way."
        
        else:
            return False, "Invalid response. Please reply 'safe' or 'help'"
    
    def _resolve_alert(self, alert_info, resolution_message):
        """Resolve an alert"""
        vehicle_id = alert_info["vehicle_id"]
        alert_id = alert_info["id"]
        
        alert_info["status"] = AlertStatus.RESOLVED
        
        # Cancel any pending timers
        if alert_id in self.alert_timers:
            self.alert_timers[alert_id].cancel()
            del self.alert_timers[alert_id]
        
        # Update database
        self.db.update_alert_status(
            alert_id, 
            "resolved", 
            driver_responded=True, 
            response_message=resolution_message
        )
        
        # Remove from active alerts
        if vehicle_id in self.active_alerts:
            del self.active_alerts[vehicle_id]
        
        print(f"[ALERT] Alert {alert_id} resolved: {resolution_message}")
    
    def resolve_by_responder(self, alert_id, responder_id, notes=None):
        """
        Resolve alert by emergency responder
        Called when someone arrives at the scene
        """
        alert = self.db.get_alert(alert_id)
        if not alert:
            return False, "Alert not found"
        
        vehicle_id = alert["vehicle_id"]
        
        if vehicle_id in self.active_alerts:
            alert_info = self.active_alerts[vehicle_id]
            self._resolve_alert(alert_info, f"Resolved by responder {responder_id}. Notes: {notes}")
        else:
            self.db.update_alert_status(alert_id, "resolved", response_message=f"Resolved by {responder_id}")
        
        # Notify relatives that situation is resolved
        for contact in self.db.get_emergency_contacts(vehicle_id):
            message = f"UPDATE: Emergency situation has been resolved. Responder is on scene."
            if contact["contact_phone"]:
                self._send_sms(contact["contact_phone"], message)
        
        return True, "Alert resolved successfully"
    
    # Notification methods
    def _send_sms(self, phone_number, message):
        """Send SMS using Twilio"""
        try:
            if self.twilio_client:
                self.twilio_client.messages.create(
                    body=message,
                    from_=TWILIO_PHONE_NUMBER,
                    to=phone_number
                )
                print(f"[SMS] Sent to {phone_number}")
                return True
            else:
                print(f"[SMS SIMULATED] To: {phone_number}, Message: {message}")
                return True
        except Exception as e:
            print(f"[SMS ERROR] {e}")
            return False
    
    def _send_email(self, email_address, subject, body):
        """Send email notification"""
        try:
            if EMAIL_ADDRESS and EMAIL_PASSWORD:
                msg = MIMEMultipart()
                msg['From'] = EMAIL_ADDRESS
                msg['To'] = email_address
                msg['Subject'] = subject
                msg.attach(MIMEText(body, 'plain'))
                
                with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                    server.starttls()
                    server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
                    server.send_message(msg)
                
                print(f"[EMAIL] Sent to {email_address}")
                return True
            else:
                print(f"[EMAIL SIMULATED] To: {email_address}, Subject: {subject}")
                return True
        except Exception as e:
            print(f"[EMAIL ERROR] {e}")
            return False
    
    def _play_voice_alert(self, message):
        """Play voice alert through speakers"""
        try:
            if self.tts_engine:
                self.tts_engine.say(message)
                self.tts_engine.runAndWait()
            else:
                print(f"[VOICE ALERT] {message}")
        except Exception as e:
            print(f"[VOICE ERROR] {e}")
    
    def _send_push_notification(self, vehicle_id, message):
        """Send push notification to mobile app"""
        # Placeholder for push notification service (Firebase, etc.)
        print(f"[PUSH] To vehicle {vehicle_id}: {message}")
    
    def _format_location(self, gps_data):
        """Format GPS data into readable location"""
        if gps_data and gps_data.get("latitude") and gps_data.get("longitude"):
            lat = gps_data["latitude"]
            lon = gps_data["longitude"]
            # In production, use reverse geocoding for address
            return f"Lat: {lat}, Lon: {lon}"
        return "Location unknown"
    
    def check_dual_side_black(self, vehicle_id, left_black, right_black):
        """
        Check for dual-side black detection
        Returns True if both sides detect black (potential severe obstruction)
        """
        if left_black and right_black:
            print(f"[ALERT] Dual-side black detected for vehicle {vehicle_id}")
            return True
        return False
    
    def get_active_alert_status(self, vehicle_id):
        """Get status of active alert for a vehicle"""
        if vehicle_id in self.active_alerts:
            alert = self.active_alerts[vehicle_id]
            return {
                "id": alert["id"],
                "status": alert["status"].value,
                "type": alert["type"],
                "attempt_count": alert["attempt_count"],
                "created_at": alert["created_at"].isoformat()
            }
        return None