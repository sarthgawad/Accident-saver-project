"""
ESP32 Configuration File
"""

# WiFi Configuration
WIFI_SSID = "YOUR_WIFI_SSID"
WIFI_PASSWORD = "YOUR_WIFI_PASSWORD"

# Server Configuration
SERVER_URL = "http://YOUR_SERVER_IP:5000"
DEVICE_ID = "ESP32_001"  # Unique identifier for this ESP32

# Sensor Configuration
SENSOR_TYPE = "STREET_LIGHT"  # Options: "STREET_LIGHT" or "IN_CAR_CAMERA"

# Pin Configuration
LIGHT_SENSOR_PIN = 34  # Analog pin for light sensor (LDR)
CAMERA_TRIGGER_PIN = 32  # Digital pin for camera module trigger
LED_STATUS_PIN = 2  # Built-in LED for status indication

# Thresholds
BLACK_THRESHOLD = 500  # ADC value below which is considered "black"
SENSOR_READ_INTERVAL = 100  # milliseconds between readings
SEND_INTERVAL = 1000  # milliseconds between server updates

# Camera Module (if using OV2640 or similar)
CAMERA_ENABLED = False