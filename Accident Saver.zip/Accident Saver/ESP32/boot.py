"""
ESP32 Boot File - Runs on startup
"""

import network
import time
from config import WIFI_SSID, WIFI_PASSWORD

def connect_wifi():
    """Connect to WiFi network"""
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    
    if not wlan.isconnected():
        print(f"Connecting to WiFi: {WIFI_SSID}")
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)
        
        # Wait for connection with timeout
        timeout = 30
        while not wlan.isconnected() and timeout > 0:
            time.sleep(1)
            timeout -= 1
            print(".", end="")
        
        if wlan.isconnected():
            print(f"\nConnected! IP: {wlan.ifconfig()[0]}")
            return True
        else:
            print("\nFailed to connect to WiFi")
            return False
    else:
        print(f"Already connected. IP: {wlan.ifconfig()[0]}")
        return True

# Connect to WiFi on boot
connect_wifi()