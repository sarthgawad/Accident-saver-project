"""
Server Configuration File
"""

import os
from dotenv import load_dotenv

load_dotenv()

# Server Configuration
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 5000
DEBUG = True

# Database
DATABASE_PATH = "car_safety.db"

# Alert Configuration
ALERT_TIMEOUT = 30  # Seconds to wait for driver response
REPEAT_ALERT_INTERVAL = 15  # Seconds between repeated alerts
MAX_ALERT_ATTEMPTS = 5  # Maximum alert attempts before escalation

# Twilio Configuration (for SMS)
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER", "")

# Email Configuration
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS", "")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD", "")

# Emergency Services (Example numbers - replace with actual)
EMERGENCY_CONTACTS = {
    "police": "100",
    "ambulance": "102",
    "fire": "101",
    "emergency": "112"
}

# GPS/Location API (for nearby people alerts)
LOCATION_API_KEY = os.getenv("LOCATION_API_KEY", "")

# Sensor Thresholds
BLACK_DETECTION_THRESHOLD = 500
DUAL_SIDE_CONFIRMATION_REQUIRED = True

# Alert Messages
ALERT_MESSAGES = {
    "driver_check": "Are you safe? Please respond within {timeout} seconds.",
    "accident_alert": "EMERGENCY: Possible accident detected at location: {location}. Vehicle ID: {vehicle_id}",
    "relative_notification": "Alert: A potential accident involving your relative's vehicle has been detected at {location}. Emergency services have been notified.",
    "nearby_alert": "CAUTION: Accident reported nearby at {location}. Please be cautious."
}