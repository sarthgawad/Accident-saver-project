An automated safety feature for cars that detects accidents/obstructions and sends emergency alerts.

## Features

- **Sensor Detection**: ESP32 sensors detect "black" conditions (obstruction/accident)
- **Driver Alerts**: System sends alerts to driver asking if they're safe
- **Auto-Escalation**: If no response, alerts emergency contacts, police, hospitals
- **Continuous Monitoring**: Alerts continue until situation is resolved
- **Real-time Dashboard**: Web interface for monitoring